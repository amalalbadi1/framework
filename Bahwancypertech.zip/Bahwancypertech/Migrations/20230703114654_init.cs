﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bahwancypertech.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Blog",
                columns: table => new
                {
                    iD = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<int>(type: "int", nullable: false),
                    doeription = table.Column<int>(type: "int", nullable: false),
                    imag = table.Column<int>(type: "int", nullable: false)
                }
                constraints: table =>
                {
                    table.PrimaryKey("PK_Blog", x => x.iD);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Blog");
        }
    }
}
