﻿using Bahwancypertech.Models;
using Microsoft.EntityFrameworkCore;

namespace Bahwancypertech.data
{
    public class ApplicationDbContext: DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
        {
        
        }    
        public DbSet<Blog> Blog { get; set; }

    }
}
