﻿namespace Bahwancypertech.Models
{
    public class Blog
    {

        public int iD { get; set; }
        public int name { get; set; }
        public int doeription { get; set; }

        public int imag { get; set; }
    }
}
