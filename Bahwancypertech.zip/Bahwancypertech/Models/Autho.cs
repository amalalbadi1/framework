﻿namespace Bahwancypertech.Models
{
    public class Autho
    {

        public int id { get; set; }
        public string name { get; set; }
        public string field { get; set; }
        public string age { get; set; }
    }
}
