﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace efcore.Migrations
{
    /// <inheritdoc />
    public partial class manytomany : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tag",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tag", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "posttag",
                columns: table => new
                {
                    PostspostiD = table.Column<int>(type: "int", nullable: false),
                    Tagsid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_posttag", x => new { x.PostspostiD, x.Tagsid });
                    table.ForeignKey(
                        name: "FK_posttag_post_PostspostiD",
                        column: x => x.PostspostiD,
                        principalTable: "post",
                        principalColumn: "postiD",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_posttag_tag_Tagsid",
                        column: x => x.Tagsid,
                        principalTable: "tag",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_posttag_Tagsid",
                table: "posttag",
                column: "Tagsid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "posttag");

            migrationBuilder.DropTable(
                name: "tag");
        }
    }
}
