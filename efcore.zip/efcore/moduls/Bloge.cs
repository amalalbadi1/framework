﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace efcore.moduls
{
    internal class Bloge
    {
        public int iD { get; set; }
        public int name { get; set; }
        public int doeription { get; set; }

        public int imag { get; set; }

        public int AuthorID { get; set; }
        public Author author { get; set; }
        public List<post> post { get; set; }
    }
}
