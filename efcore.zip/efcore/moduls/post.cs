﻿using Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace efcore.moduls
{
    internal class post
    {
        public int postiD { get; set; }
        public int posttitel { get; set; }
        public int posttAther { get; set; }
        public Bloge bloge { get; set; }
        public ICollection<tag> Tags { get; set; }
    }
}
