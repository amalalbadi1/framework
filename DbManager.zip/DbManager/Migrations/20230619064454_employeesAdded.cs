﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DbManager.Migrations
{
    /// <inheritdoc />
    public partial class employeesAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
