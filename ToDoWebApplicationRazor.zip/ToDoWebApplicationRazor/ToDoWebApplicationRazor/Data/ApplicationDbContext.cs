﻿using Microsoft.EntityFrameworkCore;
using ToDoWebApplicationRazor.Models;

namespace ToDoWebApplicationRazor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
            
        }
        public DbSet<ToDoRazor> toDoRazors { get; set; }
    }
}
