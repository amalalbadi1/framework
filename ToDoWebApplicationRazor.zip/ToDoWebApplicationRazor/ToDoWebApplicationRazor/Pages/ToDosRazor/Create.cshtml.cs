using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ToDoWebApplicationRazor.Data;
using ToDoWebApplicationRazor.Models;

namespace ToDoWebApplicationRazor.Pages.ToDosRazor
{
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        [BindProperty]
        public ToDoRazor ToDosRazor { get; set; }
        public CreateModel(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult OnPost()
        {
            _db.toDoRazors.Add(ToDosRazor);
            _db.SaveChanges();
            return RedirectToPage("Index");
        }
    }
}
