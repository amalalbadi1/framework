using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ToDoWebApplicationRazor.Data;
using ToDoWebApplicationRazor.Models;

namespace ToDoWebApplicationRazor.Pages.ToDosRazor
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        public List<ToDoRazor> toDoRazors { get; set; }
        public IndexModel(ApplicationDbContext db)
        {
            _db = db;
        }
        
        public void OnGet()
        {
            toDoRazors = _db.toDoRazors.ToList();
        }
    }
}
