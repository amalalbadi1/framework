using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ToDoWebApplicationRazor.Data;
using ToDoWebApplicationRazor.Models;

namespace ToDoWebApplicationRazor.Pages.ToDosRazor
{
    public class DeleteModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        [BindProperty]
        public ToDoRazor toDoRazor { get; set; }
        public DeleteModel(ApplicationDbContext db)
        {
            _db = db;
        }

        public RedirectToPageResult OnGet(int? id)
        {
            toDoRazor = _db.toDoRazors.Find(id);
            _db.toDoRazors.Remove(toDoRazor);
            _db.SaveChanges();
            return RedirectToPage("Index");
        }
    }
}
