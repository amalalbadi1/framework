﻿using System.ComponentModel.DataAnnotations;

namespace ToDoWebApplicationRazor.Models
{
    public class ToDoRazor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateTime { get; set; }
    }
}
